let comida = [
  [
    ['pimenta', 'arroz', 'feijão'],
    ['sorvete', 'farinha', 'bolacha']
  ],
  [
    ['batata frita', 'nugett', 'pizza'],
    ['açai','coxinha']
  ]  
];
let comidaescolida = "";

function setup() {
  createCanvas(400, 400);
  comidaescolida = comida[1][0][2];
}
function draw() {
  background(220);
  
  
  fill(255);
  rect(50, 70, 300, 50, 10);
  
  
  fill(0);
  textSize(18);
  textAlign(CENTER, CENTER);
  text(comidaescolida, 200, 95);
}